# NetScaler cleanup + GitLab scheduled pipeline

This package keeps the PowerShell GUI for initial configuration and uses the
same script in non-interactive CLI mode for GitLab schedules.

## Important architecture

- The GUI is used once to enter appliance IPs, username, cleanup choices and thresholds.
- The GUI saves `NetScalerCleanup.settings.json` to a local folder on the Windows management server.
- The NetScaler password is **not** stored in that JSON file. Store it once in GitLab as a masked CI/CD variable named `NS_PASSWORD`.
- GitLab schedule starts a pipeline. A self-hosted Windows GitLab Runner on the management server executes the PowerShell script.
- The runner machine must have network access to the NetScaler management IPs and permission to read the local settings file.
- The scheduled pipeline runs in TEST mode by default. TEST mode plans the deletions and estimates space; it does not delete files.

The script never starts a NetScaler upgrade.

## 1. Prepare the Windows management server

Create these folders:

```powershell
New-Item -ItemType Directory -Force C:\NetScalerCleanup\Config
New-Item -ItemType Directory -Force C:\NetScalerCleanup\Work
```

Use a dedicated Windows service account for GitLab Runner where possible. Give that account:
- Read access to `C:\NetScalerCleanup\Config\NetScalerCleanup.settings.json`
- Modify access to the checked-out project folder and its `reports` folder
- Network connectivity to each NetScaler management IP over the required HTTP/HTTPS port

Do not expose the NetScaler management interface to the public internet just to make the runner work.

## 2. Configure the GUI once

After cloning this repository on the Windows management server, open PowerShell in the project folder and run:

```powershell
.\NetScalerCleanup-Updated.ps1 -SettingsPath "C:\NetScalerCleanup\Config\NetScalerCleanup.settings.json"
```

In the GUI:
1. Enter each NetScaler management IP (one per line; include both HA nodes if the workflow requires both).
2. Enter the NetScaler username.
3. Select the protocol and cleanup options agreed with the client.
4. Review the `/var/nsinstall`, `/var/log`, `/var/nslog` and backup options carefully.
5. Enter the agreed `/var` and `/flash` minimum free-space thresholds.
6. Enter the NetScaler password in the GUI only if you are doing a manual GUI test. The script does not save this password.
7. Click **Save Settings**. This creates the JSON file at the path above.
8. Run **Test** first and inspect the report. Confirm the KEEP/DELETE plan with the client before any real deletion.

The password entered in the GUI is for that GUI session. It is not reused by GitLab. For unattended jobs, GitLab supplies the password through `NS_PASSWORD`.

## 3. Put the project in a private GitLab repository

Push these files to a private GitLab project:
- `NetScalerCleanup-Updated.ps1`
- `.gitlab-ci.yml`
- `.gitignore`
- `README.md`

Do **not** commit the live `NetScalerCleanup.settings.json`, passwords, tokens, or reports. The `.gitignore` excludes the settings file and reports folder.

## 4. Install/register a Windows GitLab Runner

Install GitLab Runner on the same Windows management server (or another Windows server with equivalent private network access).

Register it with:
- Executor: `shell`
- Shell: `powershell`
- Tag: `windows-netscaler`
- Run untagged jobs: disabled (recommended)

The runner must be online for the schedule to execute. If GitLab.com shared runners are used instead, they generally will not be able to reach private NetScaler IPs unless your organisation has deliberately configured private network connectivity.

After registration, confirm the runner is online in **GitLab project → Settings → CI/CD → Runners**.

## 5. Add the password in GitLab

Open **GitLab project → Settings → CI/CD → Variables → Add variable**.

Create:

| Key | Value |
|---|---|
| `NS_PASSWORD` | NetScaler account password |

Recommended variable settings:
- **Masked**: enabled
- **Hidden**: enabled if available
- **Protected**: enable only if the pipeline runs from a protected branch/tag and the schedule targets that protected ref
- Environment scope: `*`

Do not put the password in `.gitlab-ci.yml`, JSON, source code, or a normal GitLab variable file.

The username is read from the saved settings JSON. If you need to override it, the script supports `-Username`, but the included pipeline uses the saved GUI username.

## 6. Confirm the settings path

The pipeline defaults to:

```text
C:\NetScalerCleanup\Config\NetScalerCleanup.settings.json
```

Make sure the GUI saved the file at exactly this location and that the GitLab Runner service account can read it.

If you choose another path, update `NETSCALER_SETTINGS_PATH` under the `variables` section in `.gitlab-ci.yml`, or define it as a GitLab CI/CD variable.

## 7. Test the pipeline manually

In GitLab:
1. Open **Build → Pipelines** (or **CI/CD → Pipelines**, depending on the GitLab version).
2. Select **Run pipeline**.
3. Use the protected branch that contains the YAML file.
4. Leave `CLEANUP_MODE` as `test` (or add pipeline variable `CLEANUP_MODE=test`).
5. Run the pipeline and inspect the job log and downloaded `reports/` artifact.

The job exits with failure if any appliance returns `FAIL` or `ERROR`, or if credentials/settings/report generation fail.

## 8. Create the schedule

Open **Build → Pipeline schedules** (or **CI/CD → Schedules**):
1. Create a schedule.
2. Select the branch containing `.gitlab-ci.yml`.
3. Choose the required timezone and cron expression.
4. Add schedule variable `CLEANUP_MODE` = `test`.
5. Save and run the schedule once manually to confirm it works.

Choose the run time with the client and operations team. Do not assume a weekly or daily schedule without approval.

## 9. Enable real deletion only after approval

After several successful TEST runs and client sign-off:
1. Confirm every file marked `DELETE` is approved for removal.
2. Confirm rollback/build preservation rules and backup behaviour with the client.
3. Confirm the fresh backup has been created and verified as expected.
4. Change the schedule variable `CLEANUP_MODE` from `test` to `real`.
5. Run a controlled real test window with an operator available.
6. Review the CSV/log artifact and verify disk space in the NetScaler UI.

A `real` run permanently deletes the items selected by the cleanup rules. Keep the schedule in TEST mode until the deletion plan is approved.

## What runs automatically vs. what remains manual

| Activity | How often |
|---|---|
| Enter appliance IPs, username and cleanup settings | One-time, then only when changed |
| Store/update NetScaler password in GitLab variable | One-time, then rotate when required |
| Open the PowerShell GUI | Not needed for scheduled runs |
| Run cleanup | Automatically when the schedule triggers |
| Review pipeline result and report | After each run |
| Approve changes to cleanup rules / real deletion | Manual change control |

## Troubleshooting

- **Runner is offline / job pending**: check the Windows GitLab Runner service and runner tag.
- **Cannot reach appliance**: check routing, firewall rules, management IP and selected protocol from the runner host.
- **NS_PASSWORD missing**: check the CI/CD variable name, protected branch/ref and variable scope.
- **Settings file not found**: run the GUI with the exact `-SettingsPath` shown above and click Save Settings.
- **Access denied to settings/reports**: grant the runner service account the required NTFS permissions.
- **Job returns FAIL**: inspect the CSV/log artifact; the disk may remain below the agreed minimum.
- **Do not** change the job to `real` merely to make a pipeline pass.

## Safety notes

This is an integration starter package based on the supplied PowerShell script. Validate it against a non-production or approved test appliance first. In particular, have the NetScaler administrator review the cleanup plan and backup/rollback behaviour before enabling real deletion. The script's TEST report is a projection, not proof that a real cleanup will free exactly that amount of space.
