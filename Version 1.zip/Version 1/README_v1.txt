
==============================================================================
PART 1  DISK CLEANUP           (Run NetScaler Cleanup.bat)
==============================================================================
Frees space in /var on each appliance, then checks it against the free space
the upgrade needs. It never starts an upgrade.

It cleans three places:

  /var/nsinstall      every installer file (.tgz/.tar/.gz) and build folder
                      (adc.version and installns_state files are always kept)
  /var/log            old logs: the rotated copies such as ns.log.0.gz,
                      ns.log.2 or messages.3.gz. The log files NetScaler is
                      writing to right now (ns.log, messages, ...) are never
                      deleted.
  /var/ns_sys_backup  the NetScaler system backup folder (the folder your team
                      called /var/ns_sys/backup). It first creates a NEW
                      system backup, then deletes the old ones. If the new
                      backup cannot be created, the old ones are kept, so
                      the appliance is never left without a backup.

How to run it:
1. Enter your NetScaler IPs, one per line (both nodes of each HA pair),
   and your NetScaler username and password (the password is never saved).
2. Under "What to clean", "/var/log: delete old rotated logs" and
   "/var/ns_sys_backup: replace backup" are ticked. Untick
   either one to skip it. The backup level can be "full" (default) or "basic".
3. Click "Test run" first. It lists every file it would delete in each folder
   and deletes nothing. Its /var estimate allows for the size of the new
   backup.
4. If the list looks right, click "Real run" and confirm.

Options:
  Keep the running build .tgz (rollback)
                      off by default, so all .tgz files go. Tick it to keep
                      the installer of the build running now and any newer
                      build (e.g. an upgrade image already copied there).
  Also keep these builds   builds to keep, e.g. 14.1-73.49
  Never delete             file names or patterns that must never be deleted
Only folders under /var are touched. /flash is never touched.
Note: if the upgrade image was copied into /var/nsinstall it is removed too;
the upgrade job uploads it again when it runs ("Upload at the time of
execution").

Results:  PASS   enough free space for the upgrade
          FAIL   still below the minimum, needs manual attention
          ERROR  could not connect or log in, see the details box
