@echo off
rem Opens the cleanup window. Uses the PowerShell built into Windows.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0NetScalerCleanup.ps1"
if errorlevel 1 pause
